A=[0.5,0.5];
B=[0.25,0.75];
C=[0.125,0.875];

kl=zeros(3,3);
kl(1,1)=KL(A,A);kl(1,2)=KL(A,B);kl(1,3)=KL(A,C);
kl(2,1)=KL(B,A);kl(2,2)=KL(B,B);kl(2,3)=KL(B,C);
kl(3,1)=KL(C,A);kl(3,2)=KL(C,B);kl(3,3)=KL(C,C);

function kl = KL(x,y)
kl = x(1)*log2(x(1)/y(1))+x(2)*log2(x(2)/y(2));
end