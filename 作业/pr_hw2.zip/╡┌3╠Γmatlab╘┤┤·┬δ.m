% n = input("input the number of samples");
% data = zeros(n,2);
% pos = 0;
% for i = 1 : n
%     data(i,1) = input("label");
%     data(i,2) = input("score");
%     if data(i,1) == 1
%         pos = pos + 1;
%     end
% end
% data = sortrows(data,-2);
n=10;
pos = 5;
data = [1,1.0; 2,0.9; 1,0.8; 1,0.7; 2,0.6; 1,0.5; 2,0.4; 2,0.3; 2,0.2; 1,0.1];
precision = zeros(n+1,1);
recall = zeros(n+1,1);
precision(1) = 1;
recall(1) = 0;
for i = 2 : n+1
    tp = 0;
    for j = 1 : i-1
        if data(j,1) == 1
            tp = tp + 1;
        end
    end
    precision(i) = tp / (i-1);
    recall(i) = tp / pos;
end
AUC_PR = zeros(n+1,1);
AP = zeros(n+1,1);
for i = 1 : n
    AUC_PR(i) = (recall(i+1)-recall(i))*(precision(i+1)+precision(i))/2;
    AP(i) = (recall(i+1)-recall(i))*precision(i+1);
end
AUC_PR(n+1) = sum(AUC_PR(1:n));
AP(n+1) = sum(AP(1:n));
plot(recall, precision);